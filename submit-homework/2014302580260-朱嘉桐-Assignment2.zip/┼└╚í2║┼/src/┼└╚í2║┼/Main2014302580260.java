package ��ȡ2��;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class Main2014302580260 {
public  Document getDocument (String url){
	try {
    return Jsoup.connect(url).get();}   
	catch (IOException e) 
	{
    e.printStackTrace();
    }
    return null;
    }
public static void main(String[] args) throws IOException{
	Main2014302580260 t = new Main2014302580260();
    Document doc = t.getDocument("http://staff.whu.edu.cn/show.jsp?lang=cn&n=Ai Xin Ping");
    Elements element1=doc.select("[class=details col-md-10 col-sm-9 col-xs-7]");
    Elements element2=element1.select("h3");
    String name=element2.get(0).text();
    System.out.println(name);
    Elements element3=element1.select("p");
    String information=element3.get(0).text();
    System.out.println(information);
    Pattern p=Pattern.compile("[\\w[.-]]+@[\\w[.-]]+\\.[\\w]+");
	Matcher m=p.matcher(information);
	while(m.find()){
		System.out.println(m.group());
	}
	Pattern s=Pattern.compile("[0-9]{11}");
	Matcher ma=s.matcher(information);
	while(ma.find()){
		System.out.println(ma.group());
	}
	FileOutputStream fs = new FileOutputStream(new File("D:\\text1.txt"));
	PrintStream a = new PrintStream(fs);
	a.println(name);
	a.println(information);
	a.close();
    }
	
}
